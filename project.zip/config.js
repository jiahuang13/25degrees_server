//這是一個全局的配置文件

module.exports = {
  //加密和解密token的密鑰
  jwtSecretKey:'hohohohehehehe :ppp',
  //token效期
  expiresIn: '10h'
}